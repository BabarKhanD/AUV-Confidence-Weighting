import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99
from filters.sweep import run_any, ci

SENS = ("dvl", "vision", "slam")
SEEDS = range(1001, 1031)


def hard_run(seed, scenario, win=10, hi=6.0, lo=3.5):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    trusted = {s: True for s in SENS}
    log = np.ones((N, 3), dtype=bool)
    switches = 0
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            hist[s].append(min(kf.nis(z[s][k], H, R), CHI2_99))
        for s in SENS:
            m = np.mean(hist[s])
            if trusted[s] and m > hi:
                trusted[s] = False
                switches += 1
            elif (not trusted[s]) and m < lo:
                trusted[s] = True
                switches += 1
        for s in SENS:
            if trusted[s]:
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2
                kf.update(z[s][k], H, R, CHI2_99)
        est[k] = kf.x[:2]
        log[k] = [trusted[s] for s in SENS]
    err = np.linalg.norm(est - d["pos"], axis=1)
    q = np.array([d["quality"][s] for s in SENS]).T
    bad = q < 0.5
    t_in = log[bad].mean() if bad.any() else np.nan
    t_out = log[~bad].mean()
    return float(np.sqrt((err ** 2).mean())), switches, t_in, t_out


def oracle_run(seed, scenario, gate=CHI2_99):
    d = generate(seed, scenario=scenario)
    z, q = d["z"], d["quality"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    sig = {"dvl": np.full(N, 0.05),
           "vision": 0.5 + 4.0 * (1 - q["vision"]),
           "slam": 0.8 + 4.0 * (1 - q["slam"])}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            kf.update(z[s][k], H, np.eye(2) * sig[s][k] ** 2, gate)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return float(np.sqrt((err ** 2).mean()))


if __name__ == "__main__":
    for sc in ("A", "B"):
        gat = np.array([run_any(s, 1.0, "gated", 25.0, scenario=sc)[0] for s in SEEDS])
        sft = np.array([run_any(s, 1.0, "soft", 13.8, scenario=sc)[0] for s in SEEDS])
        sag = np.array([run_any(s, 1.0, "sage", 13.8, scenario=sc)[0] for s in SEEDS])
        ora = np.array([oracle_run(s, sc) for s in SEEDS])
        hr = [hard_run(s, sc) for s in SEEDS]
        hard = np.array([x[0] for x in hr])
        print(f"Scenario {sc}, seeds 1001-1030, RMSE (m)")
        for name, x in (("gated (gate 25)", gat), ("hard selector", hard),
                        ("soft (gate 13.8)", sft), ("sage-husa style", sag),
                        ("oracle fusion", ora)):
            m, h = ci(x)
            print(f"  {name:18s} {m:.3f} +/- {h:.3f}")
        print(f"  hard selector: mean switches {np.mean([x[1] for x in hr]):.1f}, "
              f"trusted inside failure zones {np.nanmean([x[2] for x in hr]):.2f}, "
              f"outside {np.mean([x[3] for x in hr]):.2f}")
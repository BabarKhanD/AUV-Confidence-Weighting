import json
import numpy as np
from sim.sim import N
from filters.diagB import err_single, err_imm
from filters.sweep import ci

SEEDS = range(4001, 4041)

with open("results/frozen.json") as f:
    FZ = json.load(f)


def turn_mask(n=N):
    k = np.arange(n)
    return ((k - 125) % 150) < 50


def per_seed(e, mask=None):
    if mask is not None:
        e = e[:, mask]
    return np.sqrt((e ** 2).mean(axis=1))


if __name__ == "__main__":
    tm = turn_mask()
    g, s_, i = FZ["gated"], FZ["soft"], FZ["imm"]
    for sc in ("B", "C"):
        E = {
            "gated": np.array([err_single(s, "gated", g["gate"], scenario=sc) for s in SEEDS]),
            "soft": np.array([err_single(s, "soft", s_["gate"], scenario=sc, win=s_["win"]) for s in SEEDS]),
            "imm": np.array([err_imm(s, i["K"], i["p_stay"], i["gate"], scenario=sc) for s in SEEDS]),
        }
        print(f"Scenario {sc}, seeds 4001-4040 (frozen settings)")
        print("  method   overall RMSE      turn windows   other steps")
        for m, e in E.items():
            mean, h = ci(per_seed(e))
            print(f"  {m:7s}  {mean:.3f} +/- {h:.3f}   "
                  f"{per_seed(e, tm).mean():.3f}          {per_seed(e, ~tm).mean():.3f}")
        for a, b in (("gated", "soft"), ("soft", "imm")):
            for label, msk in (("overall", None), ("turn windows", tm), ("other steps", ~tm)):
                d = per_seed(E[a], msk) - per_seed(E[b], msk)
                mean, h = ci(d)
                print(f"  {a} - {b}, {label:12s}: {mean:+.4f} +/- {h:.4f}  ({b} better in {(d > 0).sum()}/{len(d)})")
        print()
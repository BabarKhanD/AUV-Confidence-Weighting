import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sim.sim import N, truth, profiles
from filters.diagB import err_single, err_imm

SEEDS = range(2001, 2021)
COL = {"vision": "#0072B2", "slam": "#009E73", "dvl": "#D55E00"}
ZLAB = {"vision": "Vision fails", "slam": "SLAM fails", "dvl": "DVL fails"}
MCOL = {"gated": "#555555", "soft": "#D55E00", "imm": "#0072B2"}

plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6})


def zones(scenario):
    vis, feat, dvlq = profiles(N, scenario)
    return {"vision": vis, "slam": feat, "dvl": dvlq}


def regions(mask):
    out, start = [], None
    for i, v in enumerate(mask):
        if v and start is None:
            start = i
        if (not v) and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(mask)))
    return out


def shade(ax, scenario):
    q = zones(scenario)
    for s, qs in q.items():
        for a, b in regions(qs < 0.5):
            ax.axvspan(a, b, color=COL[s], alpha=0.15, lw=0)


def fig1():
    fig, axs = plt.subplots(2, 2, figsize=(7.16, 4.2))
    for j, sc in enumerate(("A", "B")):
        pos, _, _ = truth(N, sc)
        ax = axs[0, j]
        ax.plot(pos[:, 0], pos[:, 1], color="k", lw=0.8)
        ax.plot(pos[0, 0], pos[0, 1], "go", ms=4)
        ax.plot(pos[-1, 0], pos[-1, 1], "rs", ms=4)
        ax.set_xlabel("x (m)")
        ax.set_ylabel("y (m)")
        ax.set_title(f"({'ab'[j]}) Scenario {sc}: vehicle path", fontsize=8)
        ax = axs[1, j]
        t = np.arange(N)
        for s, qs in zones(sc).items():
            ax.plot(t, qs, color=COL[s], lw=1.0, label=ZLAB[s].replace(" fails", ""))
        ax.axhline(0.5, color="k", ls=":", lw=0.6)
        ax.set_xlabel("Time step")
        ax.set_ylabel("Sensor quality")
        ax.set_ylim(0, 1.05)
        ax.set_title(f"({'cd'[j]}) Scenario {sc}: sensor quality", fontsize=8)
        if j == 0:
            ax.legend(loc="lower left", frameon=False, ncol=3)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(f"figures/fig1_setup.{ext}", dpi=300)
    plt.close(fig)


def smooth(x, w=10):
    return np.convolve(x, np.ones(w) / w, mode="same")


def fig2():
    fig, axs = plt.subplots(2, 1, figsize=(7.16, 4.6), sharex=True)
    for ax, sc in zip(axs, ("A", "B")):
        curves = {
            "gated": np.mean([err_single(s, "gated", 13.8, scenario=sc) for s in SEEDS], axis=0),
            "soft": np.mean([err_single(s, "soft", 13.8, scenario=sc, win=40) for s in SEEDS], axis=0),
            "imm": np.mean([err_imm(s, 20.0, 0.95, 25.0, scenario=sc) for s in SEEDS], axis=0),
        }
        shade(ax, sc)
        names = {"gated": "Gated", "soft": "Soft (proposed)", "imm": "IMM"}
        for m, c in curves.items():
            ax.plot(smooth(c)[5:-5], color=MCOL[m], lw=1.0, label=names[m])
        ax.set_ylabel("Mean position error (m)")
        ax.set_title(f"Scenario {sc}", fontsize=8)
        ax.set_xlim(0, N - 10)
    axs[1].set_xlabel("Time step")
    h, l = axs[0].get_legend_handles_labels()
    from matplotlib.patches import Patch
    h += [Patch(color=COL[s], alpha=0.3) for s in ("vision", "slam", "dvl")]
    l += [ZLAB[s] for s in ("vision", "slam", "dvl")]
    axs[0].legend(h, l, loc="upper right", frameon=False, ncol=2)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(f"figures/fig2_error_time.{ext}", dpi=300)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    print("saved figures/fig1_setup.png/.pdf")
    fig2()
    print("saved figures/fig2_error_time.png/.pdf")
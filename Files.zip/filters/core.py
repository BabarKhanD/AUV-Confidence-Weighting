import numpy as np
from sim.sim import generate, N, NOM

I2, Z2 = np.eye(2), np.zeros((2, 2))
H_POS = np.hstack([I2, Z2, Z2])
H_VEL = np.hstack([Z2, I2, Z2])
F = np.block([[I2, I2, -I2], [Z2, I2, -I2], [Z2, Z2, I2]])
B = np.vstack([I2, I2, Z2])
Q = np.diag([1e-4, 1e-4, 1e-4, 1e-4, 1e-10, 1e-10])
CHI2_99 = 9.21  # 2 dof, 99%


class KF:
    def __init__(self, p0, v0):
        self.x = np.zeros(6)
        self.x[:2], self.x[2:4] = p0, v0
        self.P = np.diag([1e-2, 1e-2, 1e-2, 1e-2, 1e-6, 1e-6])

    def predict(self, acc):
        self.x = F @ self.x + B @ acc
        self.P = F @ self.P @ F.T + Q

    def nis(self, z, H, R):
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        return float(y @ np.linalg.solve(S, y))

    def update(self, z, H, R, gate=None):
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        nis = float(y @ np.linalg.solve(S, y))
        if gate is not None and nis > gate:
            return nis, False
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        IKH = np.eye(6) - K @ H
        self.P = IKH @ self.P @ IKH.T + K @ R @ K.T
        return nis, True


def run(seed, mode):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    rejected = 0
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in ("dvl", "vision", "slam"):
            if mode == "dvl_only" and s != "dvl":
                continue
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            gate = CHI2_99 if mode == "gated" else None
            _, ok = kf.update(z[s][k], H, R, gate)
            rejected += (not ok)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return err, rejected


if __name__ == "__main__":
    for mode in ("dvl_only", "fusion", "gated"):
        err, rej = run(1, mode)
        print(f"{mode:9s} RMSE {np.sqrt((err**2).mean()):7.3f}  max {err.max():7.2f}  "
              f"final {err[-1]:7.2f}  rejected {rej}")
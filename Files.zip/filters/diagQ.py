import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters import core
from filters.core import KF, H_POS, H_VEL

SENS = ("dvl", "vision", "slam")
SEEDS = range(101, 131)
BASE_Q = core.Q.copy()


def run(seed, scenario, mode, gate, qscale=1.0, win=20):
    core.Q = BASE_Q * qscale
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    infl = np.ones((N, 3))
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for i, s in enumerate(SENS):
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            if mode == "soft":
                n = kf.nis(z[s][k], H, R0)
                hist[s].append(min(n, 13.8))
                f = max(1.0, np.mean(hist[s]) / 2.0)
                infl[k, i] = f
                R = R0 * f
            else:
                R = R0
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    healthy = np.all([d["quality"][s] > 0.9 for s in SENS], axis=0)
    return err, infl, healthy


def rmse(e):
    return float(np.sqrt((e ** 2).mean()))


if __name__ == "__main__":
    print("1) Mean soft inflation factor in truly healthy steps (1.0 = no inflation)")
    for sc in ("A", "B"):
        vals, nsteps = [], []
        for s in list(SEEDS)[:20]:
            _, infl, h = run(s, sc, "soft", 13.8)
            vals.append(infl[h].mean(axis=0))
            nsteps.append(h.sum())
        v = np.mean(vals, axis=0)
        print(f"  scenario {sc}: dvl {v[0]:.2f}  vision {v[1]:.2f}  slam {v[2]:.2f}"
              f"   (healthy steps per run: {np.mean(nsteps):.0f})")

    print("2) Scenario B, RMSE vs process-noise scale (seeds 101-130)")
    for qs in (0.3, 1.0, 3.0):
        g = np.mean([rmse(run(s, "B", "gated", 25.0, qs)[0]) for s in SEEDS])
        f = np.mean([rmse(run(s, "B", "soft", 13.8, qs)[0]) for s in SEEDS])
        print(f"  Q x {qs:3.1f}:  gated {g:.3f}   soft {f:.3f}")
    core.Q = BASE_Q
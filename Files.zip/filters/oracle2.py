import numpy as np
from sim.sim import generate, N
from filters.core import KF, H_POS, H_VEL, CHI2_99
from filters.sweep import run_any, ci
from filters.imm import imm_rmse
from filters.full30 import oracle_run

SENS = ("dvl", "vision", "slam")
SEEDS = range(1001, 1031)


def oracle_clean(seed, scenario):
    d = generate(seed, scenario=scenario)
    z, q, bad = d["z"], d["quality"], d["bad"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    sig = {"dvl": np.full(N, 0.05),
           "vision": 0.5 + 4.0 * (1 - q["vision"]),
           "slam": 0.8 + 4.0 * (1 - q["slam"])}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            if bad[s][k]:
                continue
            H = H_VEL if s == "dvl" else H_POS
            kf.update(z[s][k], H, np.eye(2) * sig[s][k] ** 2, None)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return float(np.sqrt((err ** 2).mean()))


if __name__ == "__main__":
    for sc in ("A", "B"):
        res = {
            "gated (gate 25)": [run_any(s, 1.0, "gated", 25.0, scenario=sc)[0] for s in SEEDS],
            "soft (gate 13.8)": [run_any(s, 1.0, "soft", 13.8, scenario=sc)[0] for s in SEEDS],
            "IMM per-sensor": [imm_rmse(s, 20.0, 0.95, 25.0, scenario=sc) for s in SEEDS],
            "oracle noise only": [oracle_run(s, sc) for s in SEEDS],
            "oracle noise+outliers": [oracle_clean(s, sc) for s in SEEDS],
        }
        print(f"Scenario {sc}, seeds 1001-1030, RMSE (m)")
        for name, x in res.items():
            m, h = ci(x)
            print(f"  {name:22s} {m:.3f} +/- {h:.3f}")
        best = np.mean(res["oracle noise+outliers"])
        for name in ("gated (gate 25)", "soft (gate 13.8)", "IMM per-sensor"):
            print(f"  gap to upper bound, {name}: {np.mean(res[name]) - best:+.3f}")
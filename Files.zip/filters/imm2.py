import time
import itertools
import numpy as np
from filters.imm import imm_rmse
from filters.sweep import run_any, ci, SEEDS

if __name__ == "__main__":
    tune = range(101, 121)
    print("Extended IMM tuning on seeds 101-120 (RMSE):")
    rows = []
    for K, p in itertools.product((20.0, 50.0, 100.0), (0.9, 0.95)):
        r = np.mean([imm_rmse(s, K, p, 25.0) for s in tune])
        rows.append((r, K, p))
        print(f"  K={K:6.1f} p_stay={p} gate=25.0  {r:.3f}")
    rows.sort()
    _, K, p = rows[0]
    print(f"Best IMM config: K={K} p_stay={p} gate=25.0")

    print("Test on seeds 1001-1060:")
    t0 = time.time()
    imm = np.array([imm_rmse(s, K, p, 25.0) for s in SEEDS])
    t_imm = (time.time() - t0) / len(SEEDS)

    t0 = time.time()
    sft = np.array([run_any(s, 1.0, "soft", 13.8)[0] for s in SEEDS])
    t_sft = (time.time() - t0) / len(SEEDS)

    t0 = time.time()
    gat = np.array([run_any(s, 1.0, "gated", 25.0)[0] for s in SEEDS])
    t_gat = (time.time() - t0) / len(SEEDS)

    for name, x, t in (("gated (gate 25)", gat, t_gat),
                       ("soft (gate 13.8)", sft, t_sft),
                       ("IMM per-sensor", imm, t_imm)):
        m, h = ci(x)
        print(f"  {name:18s} RMSE {m:.3f} +/- {h:.3f}   {t:.2f} s/run")
    m, h = ci(imm - sft)
    print(f"  IMM - soft paired: {m:.4f} +/- {h:.4f}  (soft wins {(imm > sft).sum()}/{len(imm)})")
import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99, run

SENS = ("dvl", "vision", "slam")
SEEDS = range(101, 121)
FAIL = slice(370, 890)


def sel_err(seed, win, hi, lo, clip=CHI2_99):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    trusted = {s: True for s in SENS}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            hist[s].append(min(kf.nis(z[s][k], H, R), clip))
        for s in SENS:
            m = np.mean(hist[s])
            if trusted[s] and m > hi:
                trusted[s] = False
            elif (not trusted[s]) and m < lo:
                trusted[s] = True
        for s in SENS:
            if trusted[s]:
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2
                kf.update(z[s][k], H, R, CHI2_99)
        est[k] = kf.x[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def report(name, errs):
    e = np.array(errs)
    healthy = np.concatenate([e[:, :370], e[:, 890:]], axis=1)
    fail = e[:, FAIL]
    r = lambda x: np.sqrt((x ** 2).mean())
    print(f"{name:22s} all {r(e):.3f}   healthy {r(healthy):.3f}   failure {r(fail):.3f}")


if __name__ == "__main__":
    report("gated", [run(s, "gated")[0] for s in SEEDS])
    report("selector never-drop", [sel_err(s, 10, 1e9, 0) for s in SEEDS])
    report("selector best", [sel_err(s, 10, 6.0, 3.5) for s in SEEDS])
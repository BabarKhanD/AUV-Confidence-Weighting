import numpy as np
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99, run
from filters.soft import soft_err

SENS = ("dvl", "vision", "slam")
TEST = range(1001, 1101)


def sage_err(seed, alpha=0.1, gate=13.8):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    m = {s: 2.0 for s in SENS}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            n = kf.nis(z[s][k], H, R0)
            if n <= gate:
                m[s] = (1 - alpha) * m[s] + alpha * n
            R = R0 * max(1.0, m[s] / 2.0)
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def oracle_err(seed, gate=CHI2_99):
    d = generate(seed)
    z, q = d["z"], d["quality"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    true_sig = {"dvl": np.full(N, 0.05),
                "vision": 0.5 + 4.0 * (1 - q["vision"]),
                "slam": 0.8 + 4.0 * (1 - q["slam"])}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * true_sig[s][k] ** 2
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def rmse(e):
    return np.sqrt((e ** 2).mean())


def ci(x):
    x = np.asarray(x)
    return x.mean(), 1.96 * x.std(ddof=1) / np.sqrt(len(x))


if __name__ == "__main__":
    methods = {
        "gated": lambda s: run(s, "gated")[0],
        "soft (win20,gate13.8)": lambda s: soft_err(s, 20, 13.8, 1e9),
        "sage-husa style": sage_err,
        "oracle fusion": oracle_err,
    }
    res = {}
    for name, f in methods.items():
        res[name] = np.array([rmse(f(s)) for s in TEST])
        m, h = ci(res[name])
        print(f"{name:24s} RMSE {m:.3f} +/- {h:.3f}")
    diff = res["gated"] - res["soft (win20,gate13.8)"]
    m, h = ci(diff)
    print(f"gated - soft paired diff: {m:.3f} +/- {h:.3f}  (soft wins in {(diff > 0).sum()}/{len(diff)} seeds)")
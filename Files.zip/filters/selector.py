import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99

SENS = ("dvl", "vision", "slam")


def run_selector(seed, win=15, hi=4.0, lo=2.8, gate=CHI2_99):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    trusted = {s: True for s in SENS}
    log = np.zeros((N, 3), dtype=bool)
    switches = 0
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        # NIS for ALL sensors against the same prediction, before any update
        nis = {}
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            nis[s] = kf.nis(z[s][k], H, R)
            hist[s].append(nis[s])
        # confidence = windowed mean NIS, with hysteresis
        for s in SENS:
            m = np.mean(hist[s])
            if trusted[s] and m > hi:
                trusted[s] = False
                switches += 1
            elif (not trusted[s]) and m < lo:
                trusted[s] = True
                switches += 1
        # update with trusted sensors only (still gated per measurement)
        for s in SENS:
            if trusted[s]:
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2
                kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
        log[k] = [trusted[s] for s in SENS]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return err, switches, log


if __name__ == "__main__":
    err, sw, log = run_selector(1)
    print(f"selector  RMSE {np.sqrt((err**2).mean()):7.3f}  max {err.max():7.2f}  "
          f"final {err[-1]:7.2f}  switches {sw}")
    zones = {"dvl": (820, 70), "vision": (450, 80), "slam": (650, 80)}
    for i, s in enumerate(SENS):
        c, w = zones[s]
        a, b = c - w, c + w
        print(f"{s:7s} trusted in own failure zone [{a}-{b}]: {log[a:b, i].mean():.2f}   "
              f"elsewhere: {np.concatenate([log[:a, i], log[b:, i]]).mean():.2f}")
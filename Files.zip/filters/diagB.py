import itertools
import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL
from filters.imm import trans_matrix, MODES, M, SENS

SEEDS = range(1001, 1031)
SEGS = [(0, 150), (150, 330), (330, 470), (470, 650), (650, 780), (780, 1000)]


def err_single(seed, mode, gate, scenario="B", win=20):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            n = kf.nis(z[s][k], H, R0)
            if mode == "soft":
                hist[s].append(min(n, 13.8))
                R = R0 * max(1.0, np.mean(hist[s]) / 2.0)
            else:
                R = R0
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def err_imm(seed, K, p_stay, gate, scenario="B"):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    Pi = trans_matrix(p_stay)
    mu = np.array([np.prod([0.9 if m[s] == 0 else 0.1 for s in range(3)]) for m in MODES])
    mu /= mu.sum()
    filters = [KF(d["pos"][0], d["vel"][0]) for _ in MODES]
    est = np.zeros((N, 2))
    est[0] = filters[0].x[:2]
    for k in range(1, N):
        c = Pi.T @ mu
        mix = (Pi * mu[:, None]) / c[None, :]
        xs = np.array([f.x for f in filters])
        Ps = np.array([f.P for f in filters])
        for j, f in enumerate(filters):
            w = mix[:, j]
            x0 = w @ xs
            dx = xs - x0
            P0 = np.einsum("i,ijk->jk", w, Ps) + np.einsum("i,ij,ik->jk", w, dx, dx)
            f.x = x0
            f.P = P0
            f.predict(d["acc_m"][k - 1])
        logl = np.zeros(M)
        for j, (f, m) in enumerate(zip(filters, MODES)):
            for si, s in enumerate(SENS):
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2 * (K if m[si] else 1.0)
                y = z[s][k] - H @ f.x
                S = H @ f.P @ H.T + R
                nis = float(y @ np.linalg.solve(S, y))
                logl[j] += -0.5 * (nis + np.linalg.slogdet(2 * np.pi * S)[1])
                f.update(z[s][k], H, R, gate)
        lp = np.log(c) + logl
        lp -= lp.max()
        mu = np.exp(lp)
        mu /= mu.sum()
        mu = np.maximum(mu, 1e-6)
        mu /= mu.sum()
        xs = np.array([f.x for f in filters])
        est[k] = (mu @ xs)[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def seg_rmse(e, a, b):
    return np.sqrt((e[:, a:b] ** 2).mean())


if __name__ == "__main__":
    gat = np.array([err_single(s, "gated", 25.0) for s in SEEDS])
    sft = np.array([err_single(s, "soft", 13.8) for s in SEEDS])
    imm = np.array([err_imm(s, 20.0, 0.95, 25.0) for s in SEEDS])
    print("Scenario B, seeds 1001-1030, RMSE by time segment")
    print("  segment        gated    soft     IMM    soft-IMM")
    for a, b in SEGS:
        g, s, i = seg_rmse(gat, a, b), seg_rmse(sft, a, b), seg_rmse(imm, a, b)
        print(f"  {a:4d}-{b:4d}     {g:6.3f}  {s:6.3f}  {i:6.3f}   {s - i:+7.3f}")
    print("  all           ", "  ".join(f"{seg_rmse(x, 0, N):6.3f}" for x in (gat, sft, imm)))
import numpy as np
import itertools
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99, run

SENS = ("dvl", "vision", "slam")
SEEDS = range(101, 121)


def soft_err(seed, win, gate, drop, clip=CHI2_99):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            hist[s].append(min(kf.nis(z[s][k], H, R), clip))
        for s in SENS:
            m = np.mean(hist[s])
            if m > drop:
                continue
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2 * max(1.0, m / 2.0)
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
    return np.linalg.norm(est - d["pos"], axis=1)


def report(name, errs):
    e = np.array(errs)
    r = lambda x: np.sqrt((x ** 2).mean())
    healthy = np.concatenate([e[:, :370], e[:, 890:]], axis=1)
    print(f"{name:34s} all {r(e):.3f}  healthy {r(healthy):.3f}  failure {r(e[:, 370:890]):.3f}")


if __name__ == "__main__":
    report("gated", [run(s, "gated")[0] for s in SEEDS])
    for win, gate, drop in itertools.product((10, 20), (CHI2_99, 13.8, 1e9), (1e9, 8.0)):
        report(f"soft win={win} gate={gate:.1f} drop={drop:.0e}",
               [soft_err(s, win, gate, drop) for s in SEEDS])
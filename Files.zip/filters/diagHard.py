import numpy as np
import pandas as pd
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99

SENS = ("dvl", "vision", "slam")


def hard_trace(seed, scenario, win=10, hi=6.0, lo=3.5):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    trusted = {s: True for s in SENS}
    log = np.ones((N, 3), dtype=bool)
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            hist[s].append(min(kf.nis(z[s][k], H, R), CHI2_99))
        for s in SENS:
            m = np.mean(hist[s])
            if trusted[s] and m > hi:
                trusted[s] = False
            elif (not trusted[s]) and m < lo:
                trusted[s] = True
        for s in SENS:
            if trusted[s]:
                H = H_VEL if s == "dvl" else H_POS
                kf.update(z[s][k], H, np.eye(2) * NOM[s] ** 2, CHI2_99)
        est[k] = kf.x[:2]
        log[k] = [trusted[s] for s in SENS]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return err, log


def longest_run(mask):
    best = cur = 0
    for v in mask:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


if __name__ == "__main__":
    df = pd.read_csv("results/final_per_seed.csv")
    for sc in ("A", "B"):
        h = df[(df.scenario == sc) & (df.method == "hard")].set_index("seed").rmse
        print(f"Scenario {sc}: hard selector RMSE over 100 seeds")
        print(f"  median {h.median():.3f}   90th pct {h.quantile(0.9):.3f}   max {h.max():.3f}")
        print(f"  seeds above 1 m: {(h > 1).sum()}   above 2 m: {(h > 2).sum()}")
        worst = h.sort_values(ascending=False).index[:3]
        for seed in worst:
            err, log = hard_trace(int(seed), sc)
            alld = ~log.any(axis=1)
            print(f"  seed {seed}: RMSE {np.sqrt((err ** 2).mean()):.2f}  "
                  f"max err {err.max():.1f} at step {err.argmax()}  final err {err[-1]:.1f}")
            print(f"    fraction of steps dropped  dvl {1 - log[:, 0].mean():.2f}  "
                  f"vision {1 - log[:, 1].mean():.2f}  slam {1 - log[:, 2].mean():.2f}")
            print(f"    longest stretch with ALL sensors dropped: {longest_run(alld)} steps "
                  f"(total {alld.sum()} steps)")
        print()
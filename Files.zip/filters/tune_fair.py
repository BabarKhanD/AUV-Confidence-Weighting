import json
import itertools
import numpy as np
from filters.sweep import run_any
from filters.imm import imm_rmse

TUNE = range(101, 131)
TUNE_IMM = range(101, 121)
SCEN = ("A", "B")


def evaluate(name, grid, fn, seeds):
    rows = []
    for cfg in grid:
        per = {sc: float(np.mean([fn(s, sc, cfg) for s in seeds])) for sc in SCEN}
        rows.append((np.mean(list(per.values())), per, cfg))
    rows.sort(key=lambda r: r[0])
    print(f"{name}: tuning seeds {seeds.start}-{seeds.stop - 1}, joint score = mean of A and B")
    for avg, per, cfg in rows:
        print(f"  {str(cfg):28s} joint {avg:.3f}   A {per['A']:.3f}   B {per['B']:.3f}")
    return rows[0][2]


def edge(cfg, axes):
    return [i for i, (v, ax) in enumerate(zip(cfg, axes)) if v in (min(ax), max(ax))]


if __name__ == "__main__":
    out = {}

    g_axes = ((9.21, 13.8, 18.0, 25.0, 40.0),)
    best = evaluate("GATED (gate)", [(g,) for g in g_axes[0]],
                    lambda s, sc, c: run_any(s, 1.0, "gated", c[0], scenario=sc)[0], TUNE)
    out["gated"] = {"gate": best[0]}
    print(f"  best: {best}  on grid edge: {bool(edge(best, g_axes))}\n")

    s_axes = ((10, 20, 40), (9.21, 13.8, 18.0, 25.0))
    best = evaluate("SOFT (window, gate)", list(itertools.product(*s_axes)),
                    lambda s, sc, c: run_any(s, 1.0, "soft", c[1], win=c[0], scenario=sc)[0], TUNE)
    out["soft"] = {"win": best[0], "gate": best[1]}
    print(f"  best: {best}  on grid edge: {bool(edge(best, s_axes))}\n")

    i_axes = ((10.0, 20.0, 40.0), (13.8, 25.0))
    best = evaluate("IMM (K, gate), p_stay=0.95", list(itertools.product(*i_axes)),
                    lambda s, sc, c: imm_rmse(s, c[0], 0.95, c[1], scenario=sc), TUNE_IMM)
    out["imm"] = {"K": best[0], "p_stay": 0.95, "gate": best[1]}
    print(f"  best: {best}  on grid edge: {bool(edge(best, i_axes))}\n")

    with open("results/frozen.json", "w") as f:
        json.dump(out, f, indent=2)
    print("Saved results/frozen.json:", out)
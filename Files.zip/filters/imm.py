import numpy as np
import itertools
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL
from filters.sweep import run_any, ci, SEEDS

SENS = ("dvl", "vision", "slam")
MODES = list(itertools.product((0, 1), repeat=3))
M = len(MODES)


def trans_matrix(p_stay):
    def tp(a, b):
        return p_stay if a == b else 1.0 - p_stay
    return np.array([[np.prod([tp(a[s], b[s]) for s in range(3)]) for b in MODES]
                     for a in MODES])


def imm_rmse(seed, K, p_stay, gate, sev=1.0, scenario="A"):
    d = generate(seed, sev=sev, scenario=scenario)
    z = d["z"]
    Pi = trans_matrix(p_stay)
    mu = np.array([np.prod([0.9 if m[s] == 0 else 0.1 for s in range(3)]) for m in MODES])
    mu /= mu.sum()
    filters = [KF(d["pos"][0], d["vel"][0]) for _ in MODES]
    est = np.zeros((N, 2))
    est[0] = filters[0].x[:2]
    for k in range(1, N):
        c = Pi.T @ mu
        mix = (Pi * mu[:, None]) / c[None, :]
        xs = np.array([f.x for f in filters])
        Ps = np.array([f.P for f in filters])
        for j, f in enumerate(filters):
            w = mix[:, j]
            x0 = w @ xs
            dx = xs - x0
            P0 = np.einsum("i,ijk->jk", w, Ps) + np.einsum("i,ij,ik->jk", w, dx, dx)
            f.x = x0
            f.P = P0
            f.predict(d["acc_m"][k - 1])
        logl = np.zeros(M)
        for j, (f, m) in enumerate(zip(filters, MODES)):
            for si, s in enumerate(SENS):
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2 * (K if m[si] else 1.0)
                y = z[s][k] - H @ f.x
                S = H @ f.P @ H.T + R
                nis = float(y @ np.linalg.solve(S, y))
                logl[j] += -0.5 * (nis + np.linalg.slogdet(2 * np.pi * S)[1])
                f.update(z[s][k], H, R, gate)
        lp = np.log(c) + logl
        lp -= lp.max()
        mu = np.exp(lp)
        mu /= mu.sum()
        mu = np.maximum(mu, 1e-6)
        mu /= mu.sum()
        xs = np.array([f.x for f in filters])
        est[k] = (mu @ xs)[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return np.sqrt((err ** 2).mean())


if __name__ == "__main__":
    tune = range(101, 121)
    print("IMM tuning on seeds 101-120 (RMSE):")
    rows = []
    for K, p, g in itertools.product((5.0, 20.0), (0.95, 0.99), (13.8, 25.0)):
        r = np.mean([imm_rmse(s, K, p, g) for s in tune])
        rows.append((r, K, p, g))
        print(f"  K={K:5.1f} p_stay={p} gate={g:5.1f}  {r:.3f}")
    rows.sort()
    _, K, p, g = rows[0]
    print(f"Best IMM config: K={K} p_stay={p} gate={g}")

    print("Test on seeds 1001-1060:")
    imm = np.array([imm_rmse(s, K, p, g) for s in SEEDS])
    gat = np.array([run_any(s, 1.0, "gated", 25.0)[0] for s in SEEDS])
    sft = np.array([run_any(s, 1.0, "soft", 13.8)[0] for s in SEEDS])
    for name, x in (("gated (gate 25)", gat), ("soft (gate 13.8)", sft), ("IMM per-sensor", imm)):
        m, h = ci(x)
        print(f"  {name:18s} RMSE {m:.3f} +/- {h:.3f}")
    m, h = ci(imm - sft)
    print(f"  IMM - soft paired: {m:.4f} +/- {h:.4f}  (soft wins {(imm > sft).sum()}/{len(imm)})")
    m, h = ci(gat - imm)
    print(f"  gated - IMM paired: {m:.4f} +/- {h:.4f}  (IMM wins {(gat > imm).sum()}/{len(imm)})")
import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL

SENS = ("dvl", "vision", "slam")
SEEDS = range(101, 131)


def run(seed, scenario, variant, gate=13.8):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    long_w = 20 if variant == "fast" else (variant if isinstance(variant, int) else 20)
    hist = {s: deque(maxlen=long_w) for s in SENS}
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            if variant == "gated":
                R = R0
                g = 25.0
            else:
                n = kf.nis(z[s][k], H, R0)
                hist[s].append(min(n, 13.8))
                h = list(hist[s])
                m = min(np.mean(h), np.mean(h[-5:])) if variant == "fast" else np.mean(h)
                R = R0 * max(1.0, m / 2.0)
                g = gate
            kf.update(z[s][k], H, R, g)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return float(np.sqrt((err ** 2).mean()))


if __name__ == "__main__":
    variants = ["gated", 5, 10, 20, 40, "fast"]
    print("Soft window / recovery test, seeds 101-130 (RMSE), gate 13.8")
    print("  variant        scenario A   scenario B")
    for v in variants:
        a = np.mean([run(s, "A", v) for s in SEEDS])
        b = np.mean([run(s, "B", v) for s in SEEDS])
        name = "gated (gate 25)" if v == "gated" else (f"soft win={v}" if isinstance(v, int) else "soft fast-recov")
        print(f"  {name:15s}  {a:8.3f}     {b:8.3f}")
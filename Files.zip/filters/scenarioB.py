import numpy as np
from filters.imm import imm_rmse
from filters.sweep import run_any, ci, SEEDS


def evaluate(scenario):
    imm = np.array([imm_rmse(s, 20.0, 0.95, 25.0, scenario=scenario) for s in SEEDS])
    gat = np.array([run_any(s, 1.0, "gated", 25.0, scenario=scenario)[0] for s in SEEDS])
    sft = np.array([run_any(s, 1.0, "soft", 13.8, scenario=scenario)[0] for s in SEEDS])
    print(f"Scenario {scenario} (seeds 1001-1060, parameters frozen from A)")
    for name, x in (("gated (gate 25)", gat), ("soft (gate 13.8)", sft), ("IMM per-sensor", imm)):
        m, h = ci(x)
        print(f"  {name:18s} RMSE {m:.3f} +/- {h:.3f}")
    m, h = ci(gat - sft)
    print(f"  gated - soft paired: {m:.4f} +/- {h:.4f}  (soft wins {(gat > sft).sum()}/{len(gat)})")
    m, h = ci(imm - sft)
    print(f"  IMM - soft paired:   {m:.4f} +/- {h:.4f}  (soft wins {(imm > sft).sum()}/{len(imm)})")
    m, h = ci(gat - imm)
    print(f"  gated - IMM paired:  {m:.4f} +/- {h:.4f}  (IMM wins {(gat > imm).sum()}/{len(gat)})")


if __name__ == "__main__":
    evaluate("B")
    evaluate("A")
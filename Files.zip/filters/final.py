import json
import time
import numpy as np
import pandas as pd
from filters.sweep import run_any, ci
from filters.imm import imm_rmse
from filters.full30 import hard_run, oracle_run
from filters.oracle2 import oracle_clean

SEEDS = range(2001, 2101)
SCEN = ("A", "B")

with open("results/frozen.json") as f:
    FZ = json.load(f)


def timed(fn):
    t = time.perf_counter()
    r = fn()
    return r, time.perf_counter() - t


def methods(seed, sc):
    g, s_, i = FZ["gated"], FZ["soft"], FZ["imm"]
    return {
        "gated": lambda: run_any(seed, 1.0, "gated", g["gate"], scenario=sc),
        "soft": lambda: run_any(seed, 1.0, "soft", s_["gate"], win=s_["win"], scenario=sc),
        "sage": lambda: run_any(seed, 1.0, "sage", 13.8, scenario=sc),
        "imm": lambda: (imm_rmse(seed, i["K"], i["p_stay"], i["gate"], scenario=sc), np.nan),
        "hard": lambda: (hard_run(seed, sc)[0], np.nan),
        "oracle_noise": lambda: (oracle_run(seed, sc), np.nan),
        "oracle_clean": lambda: (oracle_clean(seed, sc), np.nan),
    }


if __name__ == "__main__":
    rows = []
    for sc in SCEN:
        for n, seed in enumerate(SEEDS, 1):
            for name, fn in methods(seed, sc).items():
                (rmse, nees), sec = timed(fn)
                rows.append((sc, seed, name, rmse, nees, sec))
            if n % 10 == 0:
                print(f"  scenario {sc}: {n}/{len(SEEDS)} seeds done", flush=True)
        pd.DataFrame(rows, columns=["scenario", "seed", "method", "rmse", "nees", "seconds"]
                     ).to_csv("results/final_per_seed.csv", index=False)

    df = pd.read_csv("results/final_per_seed.csv")
    summ = []
    pairs = [("gated", "soft"), ("sage", "soft"), ("imm", "soft"), ("gated", "imm"), ("hard", "soft")]
    for sc in SCEN:
        d = df[df.scenario == sc]
        piv = d.pivot(index="seed", columns="method", values="rmse")
        print(f"\nScenario {sc}, seeds 2001-2100, RMSE (m)")
        for m in ("gated", "hard", "soft", "sage", "imm", "oracle_noise", "oracle_clean"):
            mean, h = ci(piv[m])
            sec = d[d.method == m].seconds.mean()
            ne = d[d.method == m].nees.mean()
            ne_txt = f"{ne:.2f}" if not np.isnan(ne) else "n/a"
            print(f"  {m:13s} {mean:.3f} +/- {h:.3f}   {sec:.2f} s/run   NEES {ne_txt}")
            summ.append((sc, m, mean, h, sec, ne))
        best = piv["oracle_clean"].mean()
        for m in ("gated", "soft", "imm"):
            print(f"  gap to upper bound, {m}: {piv[m].mean() - best:+.3f}")
        for a, b in pairs:
            dm, dh = ci(piv[a] - piv[b])
            print(f"  {a} - {b} paired: {dm:+.4f} +/- {dh:.4f}  ({b} better in {(piv[a] > piv[b]).sum()}/{len(piv)} seeds)")
    pd.DataFrame(summ, columns=["scenario", "method", "rmse_mean", "ci95", "sec_per_run", "nees"]
                 ).to_csv("results/final_summary.csv", index=False)
    print("\nSaved results/final_per_seed.csv and results/final_summary.csv")
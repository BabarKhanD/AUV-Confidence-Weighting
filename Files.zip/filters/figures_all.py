import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from sim.sim import N, truth, profiles
from filters.diagB import err_single, err_imm
from filters.diagHard import hard_trace
from filters.sweep import ci

os.makedirs("figures", exist_ok=True)
with open("results/frozen.json") as f:
    FZ = json.load(f)

plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6,
                     "hatch.linewidth": 0.4})

SENS = ("dvl", "vision", "slam")
COL = {"vision": "#0072B2", "slam": "#009E73", "dvl": "#D55E00"}
SNAME = {"vision": "Vision", "slam": "SLAM", "dvl": "DVL"}
MNAME = {"gated": "Gated", "sage": "Sage-Husa style", "soft": "Soft (proposed)",
         "imm": "IMM", "oracle_clean": "Upper bound"}
MCOL = {"gated": "#999999", "sage": "#CC79A7", "soft": "#E69F00",
        "imm": "#56B4E9", "oracle_clean": "#009E73"}


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(f"figures/{name}.{ext}", dpi=300)
    plt.close(fig)
    print(f"saved figures/{name}.png/.pdf", flush=True)


def zones(scenario):
    vis, feat, dvlq = profiles(N, scenario)
    return {"vision": vis, "slam": feat, "dvl": dvlq}


def regions(mask):
    out, start = [], None
    for i, v in enumerate(mask):
        if v and start is None:
            start = i
        if (not v) and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(mask)))
    return out


def shade(ax, scenario):
    for s, qs in zones(scenario).items():
        for a, b in regions(qs < 0.5):
            ax.axvspan(a, b, color=COL[s], alpha=0.15, lw=0)


# ---------------------------------------------------------------- Fig 1
def fig1():
    fig, axs = plt.subplots(2, 2, figsize=(7.16, 4.5))
    titles = {"A": "sinusoidal path", "B": "racetrack path"}
    for j, sc in enumerate(("A", "B")):
        pos, _, _ = truth(N, sc)
        ax = axs[0, j]
        ax.plot(pos[:, 0], pos[:, 1], color="k", lw=0.8)
        ax.plot(pos[0, 0], pos[0, 1], "go", ms=4)
        ax.plot(pos[-1, 0], pos[-1, 1], "rs", ms=4)
        ax.set_xlabel("x (m)")
        ax.set_ylabel("y (m)")
        ax.set_title(f"({'ab'[j]}) Scenario {sc}: {titles[sc]}", fontsize=8)
        ax = axs[1, j]
        t = np.arange(N)
        for s, qs in zones(sc).items():
            ax.plot(t, qs, color=COL[s], lw=1.0)
        ax.axhline(0.5, color="k", ls=":", lw=0.6)
        ax.set_xlabel("Time step")
        ax.set_ylabel("Sensor quality")
        ax.set_ylim(0, 1.05)
        ax.set_title(f"({'cd'[j]}) Scenario {sc}: sensor quality", fontsize=8)
    handles = [Line2D([], [], color=COL[s], lw=1.2, label=SNAME[s]) for s in ("vision", "slam", "dvl")]
    handles += [Line2D([], [], color="g", marker="o", ls="", ms=4, label="Start"),
                Line2D([], [], color="r", marker="s", ls="", ms=4, label="End"),
                Line2D([], [], color="k", ls=":", lw=0.8, label="Failure threshold (0.5)")]
    fig.legend(handles=handles, loc="upper center", ncol=6, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    save(fig, "fig1_setup")


# ---------------------------------------------------------------- Fig 2
def get_curves():
    path = "results/fig2_curves.npz"
    if os.path.exists(path):
        z = np.load(path)
        return {k: z[k] for k in z.files}
    seeds = range(2001, 2021)
    g, s_, i = FZ["gated"], FZ["soft"], FZ["imm"]
    out = {}
    for sc in ("A", "B"):
        print(f"  computing error curves, scenario {sc} ...", flush=True)
        out[f"{sc}_gated"] = np.mean([err_single(s, "gated", g["gate"], scenario=sc) for s in seeds], axis=0)
        out[f"{sc}_soft"] = np.mean([err_single(s, "soft", s_["gate"], scenario=sc, win=s_["win"])
                                     for s in seeds], axis=0)
        out[f"{sc}_imm"] = np.mean([err_imm(s, i["K"], i["p_stay"], i["gate"], scenario=sc)
                                    for s in seeds], axis=0)
    np.savez(path, **out)
    return out


def smooth(x, w=11):
    return np.convolve(x, np.ones(w) / w, mode="same")


def fig2():
    cur = get_curves()
    style = {"gated": dict(color="#777777", ls=":", lw=1.2),
             "soft": dict(color="k", ls="-", lw=1.2),
             "imm": dict(color="#CC3311", ls="--", lw=1.1)}
    fig, axs = plt.subplots(2, 1, figsize=(7.16, 4.8), sharex=True)
    h = 5
    t = np.arange(N)
    for ax, sc in zip(axs, ("A", "B")):
        shade(ax, sc)
        for m in ("gated", "soft", "imm"):
            y = smooth(cur[f"{sc}_{m}"])
            ax.plot(t[h:-h], y[h:-h], **style[m])
        if sc == "B":
            for a in range(125, N, 150):
                ax.axvspan(a, min(a + 50, N), ymin=0, ymax=0.035, color="k", alpha=0.7, lw=0)
        ax.set_ylabel("Mean position error (m)")
        ax.set_title(f"({'ab'[sc == 'B']}) Scenario {sc}", fontsize=8)
        ax.set_xlim(0, N - 1)
    axs[1].set_xlabel("Time step")
    handles = [Line2D([], [], label="Gated", **style["gated"]),
               Line2D([], [], label="Soft (proposed)", **style["soft"]),
               Line2D([], [], label="IMM", **style["imm"])]
    handles += [Patch(color=COL[s], alpha=0.3, label=f"{SNAME[s]} fails") for s in ("vision", "slam", "dvl")]
    handles += [Patch(color="k", alpha=0.7, label="Turn window (B)")]
    fig.legend(handles=handles, loc="upper center", ncol=7, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    save(fig, "fig2_error_time")


# ---------------------------------------------------------------- Fig 3
def strips(ax, log, sc):
    q = zones(sc)
    t = np.arange(N)
    for i, s in enumerate(SENS):
        ax.fill_between(t, i, i + 0.8, where=log[:, i], step="mid", color=COL[s], lw=0)
        ax.fill_between(t, i, i + 0.8, where=q[s] < 0.5, facecolor="none",
                        edgecolor="k", hatch="////", lw=0)
    ax.set_yticks([i + 0.4 for i in range(3)])
    ax.set_yticklabels([SNAME[s] for s in SENS])
    ax.set_xlim(0, N - 1)
    ax.set_ylim(0, 3)


def fig3():
    df = pd.read_csv("results/final_per_seed.csv")
    h = df[(df.scenario == "A") & (df.method == "hard")].set_index("seed").rmse
    typical = int((h - h.median()).abs().idxmin())
    worst = int(h.idxmax())
    print(f"  fig3 seeds: typical {typical} (RMSE {h[typical]:.2f}), lock-out {worst} (RMSE {h[worst]:.2f})")
    fig, axs = plt.subplots(2, 2, figsize=(7.16, 4.8), sharex=True)
    for j, (seed, tag) in enumerate(((typical, "Typical run"), (worst, "Lock-out run"))):
        err, log = hard_trace(seed, "A")
        strips(axs[0, j], log, "A")
        axs[0, j].set_title(f"({'ab'[j]}) {tag}: seed {seed}, RMSE {h[seed]:.2f} m", fontsize=8)
        axs[1, j].semilogy(np.maximum(err, 0.02), color="k", lw=0.8)
        axs[1, j].set_xlabel("Time step")
        axs[1, j].set_ylim(0.02, 150)
    axs[1, 0].set_ylabel("Position error (m)")
    axs[1, 1].sharey(axs[1, 0])
    handles = [Patch(color=COL[s], label=f"{SNAME[s]} trusted") for s in SENS]
    handles += [Patch(facecolor="none", edgecolor="k", hatch="////", label="Own failure zone")]
    fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    save(fig, "fig3_hard_selector")


# ---------------------------------------------------------------- Fig 4
def fig4():
    df = pd.read_csv("results/final_per_seed.csv")
    methods = ["gated", "sage", "soft", "imm", "oracle_clean"]
    fig, ax = plt.subplots(figsize=(7.16, 3.0))
    w = 0.15
    for gi, sc in enumerate(("A", "B")):
        piv = df[df.scenario == sc].pivot(index="seed", columns="method", values="rmse")
        for mi, m in enumerate(methods):
            mean, hh = ci(piv[m].values)
            x = gi + (mi - 2) * w
            ax.bar(x, mean, w * 0.92, yerr=hh, capsize=2, color=MCOL[m], edgecolor="k",
                   linewidth=0.5, error_kw={"elinewidth": 0.7},
                   label=MNAME[m] if gi == 0 else None)
            ax.text(x, mean + hh + 0.006, f"{mean:.3f}", ha="center", fontsize=6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Scenario A", "Scenario B"])
    ax.set_ylabel("RMSE (m)")
    ax.set_ylim(0, 0.58)
    ax.legend(ncol=5, loc="upper center", frameon=False)
    fig.tight_layout()
    save(fig, "fig4_rmse_bars")


# ---------------------------------------------------------------- Fig 5
def fig5():
    df = pd.read_csv("results/severity.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.16, 2.8), sharey=True)
    st = {"gated": ("#777777", "o", ":"), "soft": ("k", "s", "-"), "imm": ("#CC3311", "^", "--")}
    dx = {"gated": -0.02, "soft": 0.0, "imm": 0.02}
    for ax, sc in zip(axs, ("A", "B")):
        d = df[df.scenario == sc]
        for m in ("gated", "soft", "imm"):
            xs, ys, es = [], [], []
            for sev in sorted(d.severity.unique()):
                vals = d[(d.severity == sev) & (d.method == m)].rmse.values
                mean, hh = ci(vals)
                xs.append(sev + dx[m])
                ys.append(mean)
                es.append(hh)
            c, mk, ls = st[m]
            ax.errorbar(xs, ys, yerr=es, color=c, marker=mk, ms=3.5, ls=ls, lw=1.0,
                        capsize=2, elinewidth=0.7, label=MNAME.get(m, m))
        ax.set_xlabel("Failure severity (vision and SLAM)")
        ax.set_xticks([0.5, 1.0, 1.5, 2.0])
        ax.set_title(f"({'ab'[sc == 'B']}) Scenario {sc}", fontsize=8)
    axs[0].set_ylabel("RMSE (m)")
    axs[0].legend(frameon=False, loc="upper left")
    fig.tight_layout()
    save(fig, "fig5_severity")


# ---------------------------------------------------------------- Fig 6
def fig6():
    df = pd.read_csv("results/final_per_seed.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.16, 2.8))
    ms = ["gated", "soft", "sage", "imm"]
    sec = [df[df.method == m].seconds.mean() for m in ms]
    ax = axs[0]
    ax.bar(range(4), sec, color=[MCOL[m] for m in ms], edgecolor="k", linewidth=0.5)
    for i, v in enumerate(sec):
        ax.text(i, v + 0.05, f"{v:.2f}", ha="center", fontsize=6.5)
    ax.set_ylim(0, 3.3)
    ax.set_xticks(range(4))
    ax.set_xticklabels([MNAME[m] for m in ms], rotation=20, ha="right")
    ax.set_ylabel("Seconds per run (1000 steps)")
    ratio = sec[3] / sec[1]
    ax.set_title(f"(a) Runtime (IMM / soft = {ratio:.1f}x)", fontsize=8)
    ax = axs[1]
    nm = ["gated", "sage", "soft"]
    w = 0.25
    for gi, sc in enumerate(("A", "B")):
        for mi, m in enumerate(nm):
            v = df[(df.scenario == sc) & (df.method == m)].nees.mean()
            x = gi + (mi - 1) * w
            ax.bar(x, v, w * 0.92, color=MCOL[m], edgecolor="k", linewidth=0.5,
                   label=MNAME[m] if gi == 0 else None)
            ax.text(x, v + 0.12, f"{v:.1f}", ha="center", fontsize=6.5)
    ax.axhline(2.0, color="k", ls="--", lw=0.8)
    ax.text(0.5, 2.15, "ideal = 2", fontsize=6.5, ha="center")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Scenario A", "Scenario B"])
    ax.set_ylabel("Mean NEES (2 dof)")
    ax.set_ylim(0, 10)
    ax.legend(frameon=False, loc="upper left")
    ax.set_title("(b) Covariance consistency", fontsize=8)
    fig.tight_layout()
    save(fig, "fig6_cost_consistency")


if __name__ == "__main__":
    fig1()
    fig2()
    fig3()
    fig4()
    fig5()
    fig6()
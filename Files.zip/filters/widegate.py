import numpy as np
from filters.sweep import run_any, ci, SEEDS

if __name__ == "__main__":
    print("Wide gate sweep at sev=1.0 (RMSE mean +/- CI)")
    for gate in (18.0, 25.0, 40.0, 100.0, 1e9):
        out = []
        for mode in ("gated", "soft"):
            r = [run_any(s, 1.0, mode, gate)[0] for s in SEEDS]
            m, h = ci(r)
            out.append(f"{mode} {m:.3f}+/-{h:.3f}")
        print(f"  gate={gate:9.1f}  " + "   ".join(out))
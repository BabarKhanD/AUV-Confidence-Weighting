import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL

SENS = ("dvl", "vision", "slam")
SEEDS = range(101, 131)


def run(seed, scenario, clip, win=20, gate=13.8):
    d = generate(seed, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    vis_infl = np.ones(N)
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            if clip == "gated":
                R = R0
                g = 25.0
            else:
                n = kf.nis(z[s][k], H, R0)
                hist[s].append(min(n, clip))
                f = max(1.0, np.mean(hist[s]) / 2.0)
                if s == "vision":
                    vis_infl[k] = f
                R = R0 * f
                g = gate
            kf.update(z[s][k], H, R, g)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    bad_vis = d["quality"]["vision"] < 0.5
    return float(np.sqrt((err ** 2).mean())), float(vis_infl[bad_vis].mean()) if bad_vis.any() else 1.0


if __name__ == "__main__":
    variants = ["gated", 13.8, 30.0, 60.0, 120.0, 1e9]
    print("Soft NIS-clip test, seeds 101-130, win=20, gate 13.8")
    print("  variant            A RMSE   B RMSE   vision inflation in failure zone (A, B)")
    for v in variants:
        ra = [run(s, "A", v) for s in SEEDS]
        rb = [run(s, "B", v) for s in SEEDS]
        a, b = np.mean([x[0] for x in ra]), np.mean([x[0] for x in rb])
        ia, ib = np.mean([x[1] for x in ra]), np.mean([x[1] for x in rb])
        name = "gated (gate 25)" if v == "gated" else ("soft no clip" if v >= 1e9 else f"soft clip={v:g}")
        print(f"  {name:17s}  {a:6.3f}   {b:6.3f}    {ia:5.2f}, {ib:5.2f}")
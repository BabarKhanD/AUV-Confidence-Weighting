import json
import itertools
import numpy as np
from filters.sweep import run_any
from filters.imm import imm_rmse

TUNE = range(101, 131)
TUNE_IMM = range(101, 121)
SCEN = ("A", "B")


def evaluate(name, grid, fn, seeds):
    rows = []
    for cfg in grid:
        per = {sc: float(np.mean([fn(s, sc, cfg) for s in seeds])) for sc in SCEN}
        rows.append((np.mean(list(per.values())), per, cfg))
    rows.sort(key=lambda r: r[0])
    print(f"{name}: tuning seeds {seeds.start}-{seeds.stop - 1}, joint score = mean of A and B")
    for avg, per, cfg in rows:
        print(f"  {str(cfg):28s} joint {avg:.3f}   A {per['A']:.3f}   B {per['B']:.3f}")
    return rows[0][2]


def on_edge(cfg, axes):
    return any(v in (min(ax), max(ax)) for v, ax in zip(cfg, axes))


if __name__ == "__main__":
    with open("results/frozen.json") as f:
        out = json.load(f)

    s_axes = ((40, 60, 80, 120), (13.8, 18.0))
    best = evaluate("SOFT extended (window, gate)", list(itertools.product(*s_axes)),
                    lambda s, sc, c: run_any(s, 1.0, "soft", c[1], win=c[0], scenario=sc)[0], TUNE)
    out["soft"] = {"win": best[0], "gate": best[1]}
    print(f"  best: {best}  on grid edge: {on_edge(best, s_axes)}\n")

    i_axes = ((20.0, 40.0), (25.0, 40.0, 60.0))
    best = evaluate("IMM extended (K, gate), p_stay=0.95", list(itertools.product(*i_axes)),
                    lambda s, sc, c: imm_rmse(s, c[0], 0.95, c[1], scenario=sc), TUNE_IMM)
    out["imm"] = {"K": best[0], "p_stay": 0.95, "gate": best[1]}
    print(f"  best: {best}  on grid edge: {on_edge(best, i_axes)}\n")

    with open("results/frozen.json", "w") as f:
        json.dump(out, f, indent=2)
    print("Saved results/frozen.json:", out)
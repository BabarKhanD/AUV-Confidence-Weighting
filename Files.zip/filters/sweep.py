import numpy as np
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL

SENS = ("dvl", "vision", "slam")
SEEDS = range(1001, 1061)


def run_any(seed, sev, mode, gate, win=20, alpha=0.1, scenario="A"):
    d = generate(seed, sev=sev, scenario=scenario)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    m = {s: 2.0 for s in SENS}
    nees = []
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R0 = np.eye(2) * NOM[s] ** 2
            n = kf.nis(z[s][k], H, R0)
            if mode == "soft":
                hist[s].append(min(n, 13.8))
                mm = np.mean(hist[s])
                R = R0 * max(1.0, mm / 2.0)
            elif mode == "sage":
                if n <= gate:
                    m[s] = (1 - alpha) * m[s] + alpha * n
                R = R0 * max(1.0, m[s] / 2.0)
            else:
                R = R0
            kf.update(z[s][k], H, R, gate)
        est[k] = kf.x[:2]
        e = d["pos"][k] - kf.x[:2]
        P = kf.P[:2, :2]
        nees.append(float(e @ np.linalg.solve(P, e)))
    err = np.linalg.norm(est - d["pos"], axis=1)
    return np.sqrt((err ** 2).mean()), np.mean(nees)


def ci(x):
    x = np.asarray(x)
    return x.mean(), 1.96 * x.std(ddof=1) / np.sqrt(len(x))


if __name__ == "__main__":
    print("A) gate sweep at sev=1.0 (RMSE mean +/- CI)")
    for gate in (9.21, 11.5, 13.8, 18.0):
        out = []
        for mode in ("gated", "soft", "sage"):
            r = [run_any(s, 1.0, mode, gate)[0] for s in SEEDS]
            m, h = ci(r)
            out.append(f"{mode} {m:.3f}+/-{h:.3f}")
        print(f"  gate={gate:5.2f}  " + "   ".join(out))

    print("B) paired soft vs sage at gate 13.8")
    a = np.array([run_any(s, 1.0, "sage", 13.8)[0] for s in SEEDS])
    b = np.array([run_any(s, 1.0, "soft", 13.8)[0] for s in SEEDS])
    m, h = ci(a - b)
    print(f"  sage - soft: {m:.4f} +/- {h:.4f}  (soft wins {(a > b).sum()}/{len(a)})")

    print("C) severity sweep at gate 13.8 (RMSE)")
    for sev in (0.5, 1.0, 1.5, 2.0):
        out = []
        for mode in ("gated", "soft", "sage"):
            r = [run_any(s, sev, mode, 13.8)[0] for s in SEEDS]
            out.append(f"{mode} {np.mean(r):.3f}")
        print(f"  sev={sev}  " + "   ".join(out))

    print("D) NEES (expected about 2 for 2 dof)")
    for mode in ("gated", "soft"):
        n = [run_any(s, 1.0, mode, 13.8)[1] for s in SEEDS]
        print(f"  {mode}: mean NEES {np.mean(n):.2f}")
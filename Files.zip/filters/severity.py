import json
import numpy as np
import pandas as pd
from filters.sweep import run_any, ci
from filters.imm import imm_rmse

SEEDS = range(3001, 3041)
SEVS = (0.5, 1.0, 1.5, 2.0)
SCEN = ("A", "B")

with open("results/frozen.json") as f:
    FZ = json.load(f)

if __name__ == "__main__":
    g, s_, i = FZ["gated"], FZ["soft"], FZ["imm"]
    rows = []
    for sc in SCEN:
        for sev in SEVS:
            for seed in SEEDS:
                rows.append((sc, sev, seed, "gated",
                             run_any(seed, sev, "gated", g["gate"], scenario=sc)[0]))
                rows.append((sc, sev, seed, "soft",
                             run_any(seed, sev, "soft", s_["gate"], win=s_["win"], scenario=sc)[0]))
                rows.append((sc, sev, seed, "imm",
                             imm_rmse(seed, i["K"], i["p_stay"], i["gate"], sev=sev, scenario=sc)))
            print(f"  scenario {sc}, severity {sev} done", flush=True)
        pd.DataFrame(rows, columns=["scenario", "severity", "seed", "method", "rmse"]
                     ).to_csv("results/severity.csv", index=False)

    df = pd.read_csv("results/severity.csv")
    for sc in SCEN:
        print(f"\nScenario {sc}, seeds 3001-3040, RMSE (m)")
        print("  severity   gated            soft             IMM              soft-gated   soft-IMM")
        for sev in SEVS:
            d = df[(df.scenario == sc) & (df.severity == sev)]
            p = d.pivot(index="seed", columns="method", values="rmse")
            cells = []
            for m in ("gated", "soft", "imm"):
                mean, h = ci(p[m])
                cells.append(f"{mean:.3f}+/-{h:.3f}")
            dg, _ = ci(p["soft"] - p["gated"])
            di, _ = ci(p["soft"] - p["imm"])
            print(f"  {sev:<9}  " + "  ".join(cells) + f"   {dg:+.3f}      {di:+.3f}")
    print("\nSaved results/severity.csv")
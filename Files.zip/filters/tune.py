import numpy as np
import itertools
from collections import deque
from sim.sim import generate, N, NOM
from filters.core import KF, H_POS, H_VEL, CHI2_99, run

SENS = ("dvl", "vision", "slam")
TUNE_SEEDS = range(101, 121)


def run_sel(seed, win, hi, lo, clip=CHI2_99):
    d = generate(seed)
    z = d["z"]
    kf = KF(d["pos"][0], d["vel"][0])
    est = np.zeros((N, 2))
    est[0] = kf.x[:2]
    hist = {s: deque(maxlen=win) for s in SENS}
    trusted = {s: True for s in SENS}
    switches = 0
    for k in range(1, N):
        kf.predict(d["acc_m"][k - 1])
        for s in SENS:
            H = H_VEL if s == "dvl" else H_POS
            R = np.eye(2) * NOM[s] ** 2
            hist[s].append(min(kf.nis(z[s][k], H, R), clip))
        for s in SENS:
            m = np.mean(hist[s])
            if trusted[s] and m > hi:
                trusted[s] = False
                switches += 1
            elif (not trusted[s]) and m < lo:
                trusted[s] = True
                switches += 1
        for s in SENS:
            if trusted[s]:
                H = H_VEL if s == "dvl" else H_POS
                R = np.eye(2) * NOM[s] ** 2
                kf.update(z[s][k], H, R, CHI2_99)
        est[k] = kf.x[:2]
    err = np.linalg.norm(est - d["pos"], axis=1)
    return np.sqrt((err ** 2).mean()), switches


if __name__ == "__main__":
    g = [np.sqrt((run(s, "gated")[0] ** 2).mean()) for s in TUNE_SEEDS]
    print(f"gated reference on tune seeds: RMSE {np.mean(g):.3f}")
    rows = []
    for win, hi, lo in itertools.product((10, 20, 30), (3.0, 4.0, 5.0, 6.0), (2.5, 3.0, 3.5)):
        if lo >= hi:
            continue
        r = [run_sel(s, win, hi, lo) for s in TUNE_SEEDS]
        rows.append((np.mean([x[0] for x in r]), np.mean([x[1] for x in r]), win, hi, lo))
    rows.sort()
    print("best 8 (RMSE, mean switches, win, hi, lo):")
    for r in rows[:8]:
        print(f"  {r[0]:.3f}  {r[1]:5.1f}  win={r[2]} hi={r[3]} lo={r[4]}")
import numpy as np
from sim.sim import generate, N
from filters.diagB import err_single, err_imm

SEEDS = range(101, 131)


def turn_mask(n=N):
    k = np.arange(n)
    return ((k - 125) % 150) < 50


def mismatch(scenario):
    d = generate(1, scenario=scenario)
    vel, acc = d["vel"], d["acc"]
    m = np.linalg.norm(vel[1:] - vel[:-1] - acc[:-1], axis=1)
    tm = turn_mask()[:-1]
    return m[tm].mean(), m[~tm].mean(), m.max()


def rmse(e):
    return float(np.sqrt((e ** 2).mean()))


if __name__ == "__main__":
    tm = turn_mask()
    print("1) Acceleration-model mismatch per step, |true dv - acc|")
    for sc in ("A", "B"):
        a, b, mx = mismatch(sc)
        print(f"  scenario {sc}: in B's turn-window steps {a:.4f}   other steps {b:.4f}   max {mx:.4f}")

    print("2) Scenario B error split (seeds 101-130)")
    res = {
        "gated": np.array([err_single(s, "gated", 13.8, scenario="B") for s in SEEDS]),
        "soft": np.array([err_single(s, "soft", 13.8, scenario="B", win=40) for s in SEEDS]),
        "imm": np.array([err_imm(s, 20.0, 0.95, 25.0, scenario="B") for s in SEEDS]),
    }
    for name, e in res.items():
        share = (e[:, tm] ** 2).sum() / (e ** 2).sum()
        print(f"  {name:6s} turn-window RMSE {rmse(e[:, tm]):.3f}   other RMSE {rmse(e[:, ~tm]):.3f}"
              f"   share of squared error in turn windows {share:.0%}")
    for label, msk in (("turn windows", tm), ("other steps", ~tm)):
        g = rmse(res["gated"][:, msk]) - rmse(res["soft"][:, msk])
        i = rmse(res["soft"][:, msk]) - rmse(res["imm"][:, msk])
        print(f"  {label:13s} gated - soft {g:+.3f}   soft - IMM {i:+.3f}")
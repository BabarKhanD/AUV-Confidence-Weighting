import numpy as np

N = 1000
NOM = {"dvl": 0.05, "vision": 0.5, "slam": 0.8}

# failure layouts: sensor -> list of (center, width)
LAYOUT = {
    "A": {"vision": [(450, 80)], "slam": [(650, 80)], "dvl": [(820, 70)]},
    "B": {"vision": [(60, 70), (700, 80)], "slam": [(350, 70)], "dvl": [(400, 60)]},
}
LAYOUT["C"] = LAYOUT["B"]  # C = B with an exactly consistent acceleration signal


def bump(t, c, w):
    return np.exp(-((t - c) ** 2) / (2 * w ** 2))


def quality(t, zones):
    q = np.ones_like(t)
    for c, w in zones:
        q = q - 0.95 * bump(t, c, w)
    return np.clip(q, 0.05, 1.0)


def profiles(n=N, scenario="A"):
    t = np.arange(n, dtype=float)
    L = LAYOUT[scenario]
    return quality(t, L["vision"]), quality(t, L["slam"]), quality(t, L["dvl"])


def truth(n=N, scenario="A"):
    t = np.arange(n, dtype=float)
    if scenario == "A":
        h = 0.8 * np.sin(2 * np.pi * t / 300.0)
    else:
        # racetrack: straight legs of 125 steps, then a 180-degree turn over 25 steps
        h = np.zeros(n)
        cur = 0.0
        for i in range(n):
            phase = i % 150
            if phase >= 125:
                cur += np.pi / 25.0
            h[i] = cur
    vel = np.stack([np.cos(h), np.sin(h)], axis=1)
    pos = np.cumsum(vel, axis=0) - vel
    if scenario == "C":
        # exactly consistent with the filter: v[k+1] = v[k] + acc[k]
        acc = np.zeros_like(vel)
        acc[:-1] = vel[1:] - vel[:-1]
    else:
        acc = np.gradient(vel, axis=0)
    return pos, vel, acc


def generate(seed, n=N, sev=1.0, scenario="A"):
    rng = np.random.default_rng(seed)
    pos, vel, acc = truth(n, scenario)
    vis, feat, dvlq = profiles(n, scenario)
    bias = np.cumsum(rng.normal(0, 1e-5, (n, 2)), axis=0)
    acc_m = acc + bias + rng.normal(0, 0.01, (n, 2))

    def meas(true, sigma, p_out, out_sigma):
        z = true + rng.normal(0, 1, true.shape) * sigma[:, None]
        bad = rng.random(n) < p_out
        z[bad] = true[bad] + rng.normal(0, out_sigma, (bad.sum(), 2))
        return z, bad

    z_dvl, b_dvl = meas(vel, np.full(n, 0.05), 0.7 * (1 - dvlq), 0.5)
    z_vis, b_vis = meas(pos, 0.5 + 4.0 * sev * (1 - vis),
                        np.minimum(0.95, 0.5 * sev * (1 - vis)), 15.0)
    z_slam, b_slam = meas(pos, 0.8 + 4.0 * sev * (1 - feat),
                          np.minimum(0.95, 0.5 * sev * (1 - feat)), 15.0)
    return {
        "pos": pos, "vel": vel, "acc": acc, "acc_m": acc_m,
        "z": {"dvl": z_dvl, "vision": z_vis, "slam": z_slam},
        "bad": {"dvl": b_dvl, "vision": b_vis, "slam": b_slam},
        "quality": {"dvl": dvlq, "vision": vis, "slam": feat},
    }


if __name__ == "__main__":
    for sc in ("A", "B", "C"):
        d = generate(1, scenario=sc)
        v = d["vel"][0].copy()
        p = d["pos"][0].copy()
        err = []
        for k in range(1, N):
            v = v + d["acc_m"][k - 1]
            p = p + v
            err.append(np.linalg.norm(p - d["pos"][k]))
        err = np.array(err)
        print(f"[scenario {sc}] INS dead-reckoning error at 250/500/750/999:",
              [round(float(err[i]), 1) for i in (249, 499, 749, 998)])
        mis = np.linalg.norm(d["vel"][1:] - d["vel"][:-1] - d["acc"][:-1], axis=1)
        print(f"  max |true dv - acc|: {mis.max():.4f}")
        for s in ("dvl", "vision", "slam"):
            zerr = np.linalg.norm(d["z"][s] - (d["vel"] if s == "dvl" else d["pos"]), axis=1)
            print(" ", s, "outlier rate", round(float(d["bad"][s].mean()), 3),
                  "median err", round(float(np.median(zerr)), 3),
                  "max err", round(float(zerr.max()), 2))
        print("  final true pos", d["pos"][-1].round(1))